import { Facebook, Youtube } from "lucide-react";

export const socials = [
    {
        name: "Facebook",
        href: "https://facebook.com",
        icon: Facebook
    },
    {
        name: "Youtube",
        href: "https://youtube.com",
        icon: Youtube
    },
]