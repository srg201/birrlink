export const menu = [
    {
        title: "How It Works",
        href: "how-it-works", 
    },
    {
        title: "Features",
        href: "features", 
    },
    {
        title: "FAQs",
        href: "faq", 
    },
]